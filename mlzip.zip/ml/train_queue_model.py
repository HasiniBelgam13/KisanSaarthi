import pandas as pd
import joblib

from sklearn.ensemble import RandomForestRegressor


# Load training data

data = pd.read_csv("queue_data.csv")


# Input features

X = data[
    [
        "queue_count",
        "avg_processing_time",
        "quantity",
        "staff_count"
    ]
]


# Output

y = data["waiting_time"]


# Create ML model

model = RandomForestRegressor(
    n_estimators=100,
    random_state=42
)


# Train model

model.fit(X, y)


# Save model

joblib.dump(
    model,
    "queue_waiting_model.pkl"
)


print()
print("====================================")
print(" QUEUE ML MODEL TRAINED SUCCESSFULLY")
print("====================================")
print()
print("Model saved as:")
print("queue_waiting_model.pkl")
print()
print("Training records:", len(data))