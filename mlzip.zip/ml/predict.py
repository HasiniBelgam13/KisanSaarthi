import joblib
import pandas as pd


# Load trained ML model
model = joblib.load("crop_price_model.pkl")


# Example farmer input
farmer_data = pd.DataFrame([
    {
        "crop": "Groundnut",
        "district": "Warangal",
        "season": "Rabi",
        "quantity": 20,
        "previous_price": 5800,
        "demand": 80,
        "supply": 70
    }
])


# Predict price
prediction = model.predict(farmer_data)


predicted_price = prediction[0]


print()
print("====================================")
print("       CROP PRICE PREDICTION")
print("====================================")
print()

print("Crop       :", farmer_data["crop"][0])
print("District   :", farmer_data["district"][0])
print("Quantity   :", farmer_data["quantity"][0], "Quintal")

print()

print(
    "Predicted Price : ₹",
    round(predicted_price, 2),
    "per Quintal"
)

print()
print("====================================")