import pandas as pd
import joblib

from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestRegressor


# -----------------------------------------
# 1. Load training data
# -----------------------------------------

data = pd.read_csv("crop_prices.csv")


# -----------------------------------------
# 2. Input columns
# -----------------------------------------

X = data[
    [
        "crop",
        "district",
        "season",
        "quantity",
        "previous_price",
        "demand",
        "supply"
    ]
]


# -----------------------------------------
# 3. Target column
# -----------------------------------------

y = data["price"]


# -----------------------------------------
# 4. Separate categorical and numeric data
# -----------------------------------------

categorical_features = [
    "crop",
    "district",
    "season"
]

numeric_features = [
    "quantity",
    "previous_price",
    "demand",
    "supply"
]


# -----------------------------------------
# 5. Preprocessing
# -----------------------------------------

preprocessor = ColumnTransformer(

    transformers=[

        (
            "categorical",
            OneHotEncoder(
                handle_unknown="ignore"
            ),
            categorical_features
        ),

        (
            "numeric",
            "passthrough",
            numeric_features
        )

    ]

)


# -----------------------------------------
# 6. Create ML model
# -----------------------------------------

model = RandomForestRegressor(

    n_estimators=100,

    random_state=42

)


# -----------------------------------------
# 7. Create complete pipeline
# -----------------------------------------

pipeline = Pipeline(

    steps=[

        (
            "preprocessor",
            preprocessor
        ),

        (
            "model",
            model
        )

    ]

)


# -----------------------------------------
# 8. Train model
# -----------------------------------------

pipeline.fit(X, y)


# -----------------------------------------
# 9. Save trained model
# -----------------------------------------

joblib.dump(
    pipeline,
    "crop_price_model.pkl"
)


print()
print("====================================")
print("ML MODEL TRAINED SUCCESSFULLY")
print("====================================")
print()
print("Model saved as:")
print("crop_price_model.pkl")
print()
print("Training records:", len(data))
print()