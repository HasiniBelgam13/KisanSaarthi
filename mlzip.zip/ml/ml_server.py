from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import pandas as pd

app = Flask(__name__)
CORS(app)

model = joblib.load("crop_price_model.pkl")


@app.route("/predict", methods=["POST"])
def predict():
    try:
        data = request.get_json()

        crop = data["crop"]
        district = data["district"]
        season = data["season"]
        quantity = float(data["quantity"])
        previous_price = float(data["previous_price"])
        demand = float(data["demand"])
        supply = float(data["supply"])

        input_data = pd.DataFrame([{
            "crop": crop,
            "district": district,
            "season": season,
            "quantity": quantity,
            "previous_price": previous_price,
            "demand": demand,
            "supply": supply
        }])

        predicted_price = model.predict(input_data)[0]

        return jsonify({
            "success": True,
            "crop": crop,
            "district": district,
            "predicted_price": float(predicted_price)
        })

    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "success": True,
        "message": "ML server is running"
    })


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5001, debug=True)

