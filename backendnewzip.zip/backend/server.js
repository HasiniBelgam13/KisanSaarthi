const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 5000;

/* =========================
   MIDDLEWARE
========================= */

app.use(cors());
app.use(express.json());

/* =========================
   PATHS
========================= */

const DATA_DIR = path.join(__dirname, "data");
const PUBLIC_DIR = path.join(__dirname, "public");

const farmersFile = path.join(DATA_DIR, "farmers.json");
const adminsFile = path.join(DATA_DIR, "admins.json");
const cropsFile = path.join(DATA_DIR, "crops.json");
const centersFile = path.join(DATA_DIR, "centers.json");
const requestsFile = path.join(DATA_DIR, "requests.json");
const slotsFile = path.join(DATA_DIR, "slots.json");
const paymentsFile = path.join(DATA_DIR, "payments.json");
const entriesFile = path.join(DATA_DIR, "entries.json");

/* =========================
   CREATE DATA DIRECTORY
========================= */

if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

/* =========================
   JSON HELPERS
========================= */

function readJSON(file, defaultValue = []) {
    try {
        if (!fs.existsSync(file)) {
            fs.writeFileSync(
                file,
                JSON.stringify(defaultValue, null, 2)
            );
            return defaultValue;
        }

        const content = fs.readFileSync(file, "utf8");

        if (!content.trim()) {
            return defaultValue;
        }

        return JSON.parse(content);

    } catch (error) {
        console.error("Error reading:", file);
        console.error(error.message);
        return defaultValue;
    }
}


function writeJSON(file, data) {
    fs.writeFileSync(
        file,
        JSON.stringify(data, null, 2)
    );
}


function generateId(prefix) {
    return (
        prefix +
        Date.now() +
        Math.floor(Math.random() * 1000)
    );
}


/* =========================
   INITIAL DATA
========================= */

readJSON(farmersFile, []);
readJSON(adminsFile, [
    {
        id: "admin1",
        username: "admin",
        password: "admin123",
        name: "Administrator"
    }
]);

readJSON(cropsFile, [
    {
        id: 1,
        name: "Paddy"
    },
    {
        id: 2,
        name: "Cotton"
    },
    {
        id: 3,
        name: "Maize"
    },
    {
        id: 4,
        name: "Groundnut"
    }
]);

readJSON(centersFile, []);
readJSON(requestsFile, []);
readJSON(slotsFile, []);
readJSON(paymentsFile, []);
readJSON(entriesFile, []);


/* =========================
   STATIC FRONTEND
========================= */

app.use(express.static(PUBLIC_DIR));


/* =========================
   HOME
========================= */

app.get("/", (req, res) => {
    res.sendFile(
        path.join(PUBLIC_DIR, "index.html")
    );
});


/* =========================
   HEALTH CHECK
========================= */

app.get("/api/health", (req, res) => {

    res.json({
        success: true,
        message: "Smart Procurement backend is running",
        port: PORT
    });

});


/* =========================
   FARMER REGISTER
========================= */

app.post("/api/register", (req, res) => {

    try {

        const {
            name,
            mobile,
            password,
            district
        } = req.body;

        if (!name || !mobile || !password) {

            return res.status(400).json({
                success: false,
                message: "Name, mobile and password are required"
            });

        }

        const farmers =
            readJSON(farmersFile, []);

        const existing =
            farmers.find(
                farmer => farmer.mobile === mobile
            );

        if (existing) {

            return res.status(400).json({
                success: false,
                message: "Mobile number already registered"
            });

        }

        const farmer = {

            id: generateId("F"),

            name,

            mobile,

            password,

            district: district || "",

            createdAt:
                new Date().toISOString()

        };

        farmers.push(farmer);

        writeJSON(
            farmersFile,
            farmers
        );

        res.json({

            success: true,

            message: "Registration successful",

            farmer: {
                id: farmer.id,
                name: farmer.name,
                mobile: farmer.mobile,
                district: farmer.district
            }

        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

});


/* =========================
   FARMER LOGIN
========================= */

app.post("/api/login", (req, res) => {

    try {

        const {
            mobile,
            password
        } = req.body;

        const farmers =
            readJSON(farmersFile, []);

        const farmer =
            farmers.find(
                f =>
                    f.mobile === mobile &&
                    f.password === password
            );

        if (!farmer) {

            return res.status(401).json({
                success: false,
                message: "Invalid mobile number or password"
            });

        }

        res.json({

            success: true,

            message: "Login successful",

            farmer: {
                id: farmer.id,
                name: farmer.name,
                mobile: farmer.mobile,
                district: farmer.district
            }

        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

});


/* =========================
   ADMIN LOGIN
========================= */

app.post("/api/admin/login", (req, res) => {

    try {

        const {
            username,
            password
        } = req.body;

        const admins =
            readJSON(adminsFile, []);

        const admin =
            admins.find(
                a =>
                    a.username === username &&
                    a.password === password
            );

        if (!admin) {

            return res.status(401).json({
                success: false,
                message: "Invalid admin credentials"
            });

        }

        res.json({

            success: true,

            message: "Admin login successful",

            admin: {
                id: admin.id,
                username: admin.username,
                name: admin.name
            }

        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

});


/* =========================
   GET CROPS
========================= */

app.get("/api/crops", (req, res) => {

    const crops =
        readJSON(cropsFile, []);

    res.json({
        success: true,
        crops
    });

});


/* =========================
   GET CENTERS
========================= */

app.get("/api/centers", (req, res) => {

    const centers =
        readJSON(centersFile, []);

    res.json({
        success: true,
        centers
    });

});


/* =========================
   PRICE PREDICTION
   NODE → PYTHON ML
========================= */

app.post("/api/predict-price", async (req, res) => {

    try {

        const {
            crop,
            district,
            season,
            quantity,
            previous_price,
            demand,
            supply
        } = req.body;

        if (
            !crop ||
            !district ||
            !season ||
            quantity === undefined ||
            previous_price === undefined ||
            demand === undefined ||
            supply === undefined
        ) {

            return res.status(400).json({

                success: false,

                error:
                    "All price prediction fields are required"

            });

        }


        const mlResponse =
            await fetch(
                "http://127.0.0.1:5001/predict",
                {

                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({

                        crop,

                        district,

                        season,

                        quantity,

                        previous_price,

                        demand,

                        supply

                    })

                }
            );


        const mlData =
            await mlResponse.json();


        if (
            !mlResponse.ok ||
            !mlData.success
        ) {

            return res.status(500).json({

                success: false,

                error:
                    mlData.error ||
                    "ML prediction failed"

            });

        }


        res.json({

            success: true,

            crop: mlData.crop,

            district: mlData.district,

            predictedPrice:
                Number(
                    mlData.predicted_price
                )

        });


    } catch (error) {

        console.error(
            "ML Server Error:",
            error.message
        );

        res.status(500).json({

            success: false,

            error:
                "Unable to connect to ML server. Make sure Python ML server is running on port 5001."

        });

    }

});


/* =========================
   CREATE PROCUREMENT REQUEST
========================= */

app.post("/api/requests", (req, res) => {

    try {

        const requests =
            readJSON(requestsFile, []);

        const requestData = {

            id: generateId("REQ"),

            farmerId:
                req.body.farmerId || "",

            farmerName:
                req.body.farmerName || "",

            crop:
                req.body.crop || "",

            quantity:
                Number(req.body.quantity || 0),

            unit:
                req.body.unit || "Quintal",

            district:
                req.body.district || "",

            season:
                req.body.season || "",

            predictedPrice:
                Number(
                    req.body.predictedPrice || 0
                ),

            centerId:
                req.body.centerId || "",

            centerName:
                req.body.centerName || "",

            date:
                req.body.date || "",

            slot:
                req.body.slot || "",

            token:
                req.body.token || "",

            status: "Pending",

            quality: null,

            weighedQuantity: null,

            paymentStatus: "Pending",

            createdAt:
                new Date().toISOString()

        };


        requests.push(requestData);

        writeJSON(
            requestsFile,
            requests
        );


        res.json({

            success: true,

            message:
                "Procurement request created",

            request: requestData

        });


    } catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

});


/* =========================
   GET ALL REQUESTS
========================= */

app.get("/api/requests", (req, res) => {

    const requests =
        readJSON(requestsFile, []);

    res.json({

        success: true,

        requests

    });

});


/* =========================
   GET REQUEST BY ID
========================= */

app.get("/api/requests/:id", (req, res) => {

    const requests =
        readJSON(requestsFile, []);

    const request =
        requests.find(
            r => String(r.id) === String(req.params.id)
        );

    if (!request) {

        return res.status(404).json({

            success: false,

            message: "Request not found"

        });

    }

    res.json({

        success: true,

        request

    });

});


/* =========================
   UPDATE REQUEST
========================= */

function updateRequest(id, updates) {

    const requests =
        readJSON(requestsFile, []);

    const index =
        requests.findIndex(
            r => String(r.id) === String(id)
        );

    if (index === -1) {
        return null;
    }

    requests[index] = {
        ...requests[index],
        ...updates
    };

    writeJSON(
        requestsFile,
        requests
    );

    return requests[index];
}


/* =========================
   CHECK-IN
========================= */

app.post("/api/requests/:id/checkin", (req, res) => {

    const updated =
        updateRequest(
            req.params.id,
            {
                checkedIn: true,
                checkInTime:
                    new Date().toISOString(),
                status: "Checked In"
            }
        );

    if (!updated) {

        return res.status(404).json({

            success: false,

            message: "Request not found"

        });

    }

    res.json({

        success: true,

        message: "Farmer checked in",

        request: updated

    });

});


/* =========================
   GET SLOTS FOR CENTER
========================= */

app.get("/api/slots/:centerId", (req, res) => {

    const slots =
        readJSON(slotsFile, []);

    const centerSlots =
        slots.filter(
            s =>
                String(s.centerId) ===
                String(req.params.centerId)
        );

    res.json({

        success: true,

        slots: centerSlots

    });

});


/* =========================
   GET TODAY'S ENTRIES
========================= */

app.get("/api/entries/today/:centerId", (req, res) => {

    const entries =
        readJSON(entriesFile, []);

    const today =
        new Date()
            .toISOString()
            .split("T")[0];

    const result =
        entries.filter(
            e =>
                String(e.centerId) ===
                String(req.params.centerId) &&
                e.date === today
        );

    res.json({

        success: true,

        entries: result

    });

});


/* =========================
   CREATE ENTRY
========================= */

app.post("/api/entries", (req, res) => {

    try {

        const entries =
            readJSON(entriesFile, []);

        const entry = {

            id: generateId("ENTRY"),

            requestId:
                req.body.requestId || "",

            farmerId:
                req.body.farmerId || "",

            farmerName:
                req.body.farmerName || "",

            centerId:
                req.body.centerId || "",

            centerName:
                req.body.centerName || "",

            token:
                req.body.token || "",

            date:
                req.body.date ||
                new Date()
                    .toISOString()
                    .split("T")[0],

            status: "Waiting",

            createdAt:
                new Date().toISOString()

        };

        entries.push(entry);

        writeJSON(
            entriesFile,
            entries
        );

        res.json({

            success: true,

            entry

        });

    } catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

});


/* =========================
   GET ALL ENTRIES
========================= */

app.get("/api/entries", (req, res) => {

    const entries =
        readJSON(entriesFile, []);

    res.json({

        success: true,

        entries

    });

});


/* =========================
   UPDATE ENTRY STATUS
========================= */

app.put("/api/entries/:id/status", (req, res) => {

    const entries =
        readJSON(entriesFile, []);

    const index =
        entries.findIndex(
            e =>
                String(e.id) ===
                String(req.params.id)
        );

    if (index === -1) {

        return res.status(404).json({

            success: false,

            message: "Entry not found"

        });

    }

    entries[index].status =
        req.body.status ||
        entries[index].status;

    entries[index].updatedAt =
        new Date().toISOString();

    writeJSON(
        entriesFile,
        entries
    );

    res.json({

        success: true,

        entry: entries[index]

    });

});


/* =========================
   VIRTUAL QUEUE
========================= */

app.get("/api/queue/:centerId", (req, res) => {

    const requests =
        readJSON(requestsFile, []);

    const queue =
        requests.filter(
            r =>
                String(r.centerId) ===
                String(req.params.centerId) &&
                (
                    r.status === "Pending" ||
                    r.status === "Checked In" ||
                    r.status === "Waiting" ||
                    r.status === "Processing"
                )
        );

    queue.sort(
        (a, b) =>
            new Date(a.createdAt) -
            new Date(b.createdAt)
    );

    const result =
        queue.map(
            (item, index) => ({

                ...item,

                queuePosition:
                    index + 1

            })
        );

    res.json({

        success: true,

        queue: result

    });

});


/* =========================
   QUEUE WAITING PREDICTION
========================= */

app.post("/api/predict-queue", (req, res) => {

    const queue =
        readJSON(requestsFile, []);

    const centerId =
        req.body.centerId || "";

    const waiting =
        queue.filter(
            r =>
                String(r.centerId) ===
                String(centerId) &&
                (
                    r.status === "Pending" ||
                    r.status === "Checked In" ||
                    r.status === "Waiting"
                )
        ).length;

    const estimatedMinutes =
        waiting * 15;

    res.json({

        success: true,

        waitingCount: waiting,

        estimatedWaitMinutes:
            estimatedMinutes

    });

});


/* =========================
   QUALITY CHECK
========================= */

app.post("/api/requests/:id/quality", (req, res) => {

    const qualityData = {

        quality:
            req.body.quality || "",

        moisture:
            req.body.moisture || "",

        remarks:
            req.body.remarks || "",

        qualityCheckedAt:
            new Date().toISOString(),

        status: "Quality Checked"

    };

    const updated =
        updateRequest(
            req.params.id,
            qualityData
        );

    if (!updated) {

        return res.status(404).json({

            success: false,

            message: "Request not found"

        });

    }

    res.json({

        success: true,

        message: "Quality check completed",

        request: updated

    });

});


/* =========================
   WEIGHING
========================= */

app.post("/api/requests/:id/weigh", (req, res) => {

    const weight =
        Number(req.body.weighedQuantity);

    if (isNaN(weight) || weight <= 0) {

        return res.status(400).json({

            success: false,

            message: "Invalid weighed quantity"

        });

    }

    const updated =
        updateRequest(
            req.params.id,
            {

                weighedQuantity:
                    weight,

                weighingUnit:
                    "Quintal",

                weighedAt:
                    new Date().toISOString(),

                status: "Weighed"

            }
        );

    if (!updated) {

        return res.status(404).json({

            success: false,

            message: "Request not found"

        });

    }

    res.json({

        success: true,

        message: "Weighing completed",

        request: updated

    });

});


/* =========================
   COMPLETE PROCUREMENT
========================= */

app.post("/api/requests/:id/complete", (req, res) => {

    const requests =
        readJSON(requestsFile, []);

    const request =
        requests.find(
            r =>
                String(r.id) ===
                String(req.params.id)
        );

    if (!request) {

        return res.status(404).json({

            success: false,

            message: "Request not found"

        });

    }


    if (
        request.status !== "Weighed" &&
        request.status !== "Quality Checked"
    ) {

        return res.status(400).json({

            success: false,

            message:
                "Procurement can be completed only after weighing"

        });

    }


    request.status =
        "Completed";

    request.completedAt =
        new Date().toISOString();

    request.paymentStatus =
        "Pending";


    writeJSON(
        requestsFile,
        requests
    );


    res.json({

        success: true,

        message:
            "Procurement completed",

        request

    });

});


/* =========================
   CREATE PAYMENT
========================= */

app.post("/api/payments", (req, res) => {

    try {

        const payments =
            readJSON(paymentsFile, []);

        const requests =
            readJSON(requestsFile, []);

        const request =
            requests.find(
                r =>
                    String(r.id) ===
                    String(req.body.requestId)
            );

        if (!request) {

            return res.status(404).json({

                success: false,

                message:
                    "Procurement request not found"

            });

        }


        const quantity =
            Number(
                request.weighedQuantity ||
                request.quantity ||
                0
            );

        const price =
            Number(
                request.predictedPrice ||
                0
            );

        const amount =
            quantity * price;


        const payment = {

            id:
                generateId("PAY"),

            requestId:
                request.id,

            farmerId:
                request.farmerId,

            farmerName:
                request.farmerName,

            crop:
                request.crop,

            quantity,

            pricePerQuintal:
                price,

            amount,

            paymentMethod:
                req.body.paymentMethod ||
                "Bank Transfer",

            status:
                "Paid",

            paymentDate:
                new Date().toISOString()

        };


        payments.push(payment);

        writeJSON(
            paymentsFile,
            payments
        );


        updateRequest(
            request.id,
            {
                paymentStatus: "Paid",
                paymentId: payment.id,
                status: "Paid"
            }
        );


        res.json({

            success: true,

            message:
                "Payment completed",

            payment

        });


    } catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

});


/* =========================
   GET PAYMENTS
========================= */

app.get("/api/payments", (req, res) => {

    const payments =
        readJSON(paymentsFile, []);

    res.json({

        success: true,

        payments

    });

});


/* =========================
   ADMIN STATISTICS
========================= */

app.get("/api/admin/statistics", (req, res) => {

    const farmers =
        readJSON(farmersFile, []);

    const requests =
        readJSON(requestsFile, []);

    const centers =
        readJSON(centersFile, []);

    const payments =
        readJSON(paymentsFile, []);

    const entries =
        readJSON(entriesFile, []);


    const today =
        new Date()
            .toISOString()
            .split("T")[0];


    const totalPaymentAmount =
        payments.reduce(
            (sum, payment) =>
                sum +
                Number(payment.amount || 0),
            0
        );


    const todayEntries =
        entries.filter(
            e => e.date === today
        );


    const waitingToday =
        todayEntries.filter(
            e => e.status === "Waiting"
        ).length;


    const processingToday =
        todayEntries.filter(
            e => e.status === "Processing"
        ).length;


    const completedToday =
        todayEntries.filter(
            e => e.status === "Completed"
        ).length;


    res.json({

        success: true,

        statistics: {

            totalFarmers:
                farmers.length,

            totalRequests:
                requests.length,

            pendingRequests:
                requests.filter(
                    r =>
                        r.status === "Pending"
                ).length,

            completedRequests:
                requests.filter(
                    r =>
                        r.status === "Completed" ||
                        r.status === "Paid"
                ).length,

            totalCenters:
                centers.length,

            peopleEnteredToday:
                todayEntries.length,

            waitingToday,

            processingToday,

            completedToday,

            totalPayments:
                payments.length,

            totalPaymentAmount

        }

    });

});


/* =========================
   START SERVER
========================= */

app.listen(PORT, () => {

    console.log(
        `Server running on http://localhost:${PORT}`
    );

});
